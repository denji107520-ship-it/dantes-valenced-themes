({
  default: {
    preInit({ themes }) {
      themes.registerGroup("zerotwo", { name: "Zero Two" });

      const palette = {
        HEADER_PRIMARY: "#FF9EBB",
        HEADER_SECONDARY: "#FFB3C6",
        HEADER_MUTED: "#FF85A1",
        TEXT_NORMAL: "#FF9EBB",
        TEXT_DEFAULT: "#FF9EBB",
        TEXT_PRIMARY: "#FF9EBB",
        TEXT_SECONDARY: "#FFB3C6",
        TEXT_SUBTLE: "#FF85A1",
        TEXT_STRONG: "#FFB3C6",
        TEXT_MUTED: "#FF85A1",
        TEXT_LINK: "#FFB3C6",
        TEXT_BRAND: "#FF3366",
        CHANNELS_DEFAULT: "#FF9EBB",
        CHANNELS_MUTED: "#FF7096",
        CHANNELS_ICON: "#FF85A1",
        CHANNEL_ICON: "#FF85A1",
        ICON_DEFAULT: "#FF9EBB",
        ICON_PRIMARY: "#FF9EBB",
        ICON_SECONDARY: "#FFB3C6",
        ICON_SUBTLE: "#FF85A1",
        ICON_STRONG: "#FFB3C6",
        ICON_MUTED: "#FF85A1",
        ICON_BRAND: "#FF3366",
        INTERACTIVE_NORMAL: "#FF9EBB",
        INTERACTIVE_HOVER: "#FFB3C6",
        INTERACTIVE_ACTIVE: "#FF3366",
        INTERACTIVE_MUTED: "#FF85A1",
        BACKGROUND_PRIMARY: "#59132A",
        BACKGROUND_SECONDARY: "#731736",
        BACKGROUND_SECONDARY_ALT: "#4D1024",
        BACKGROUND_TERTIARY: "#420D1F",
        BACKGROUND_BASE_LOW: "#59132A",
        BACKGROUND_BASE_LOWER: "#731736",
        BACKGROUND_BASE_LOWEST: "#420D1F",
        BACKGROUND_ACCENT: "#FF3366",
        BACKGROUND_FLOATING: "#420D1F",
        CHAT_BACKGROUND: "#420D1F",
        CHAT_INPUT_CONTAINER_BACKGROUND: "#59132A"
      };

      themes.registerTheme("zerotwo", "pink-frosted", {
        name: "Zero Two — Sakura Darling",
        description: "Frosted sakura pink & deep rosewood Zero Two theme — provided by Dante",
        getColors: (discord) => {
          const rawOverrides = {
            WHITE: "#FF9EBB",
            WHITE_500: "#FF9EBB",
            BLURPLE_500: "#FF3366",
            BRAND_260: "#FFD6E0",
            BRAND_360: "#FFB3C6",
            BRAND_400: "#FF85A1",
            BRAND_500: "#FF3366",
            BRAND_560: "#E02454",
            BRAND_600: "#B81842",
            PRIMARY_100: "#FF9EBB",
            PRIMARY_200: "#FFB3C6",
            PRIMARY_300: "#FF85A1",
            PRIMARY_400: "#FF7096",
            PRIMARY_500: "#FF3366",
            PRIMARY_600: "#59132A",
            PRIMARY_630: "#731736",
            PRIMARY_660: "#4D1024",
            PRIMARY_700: "#420D1F",
            OPACITY_8: "#FF477E26",
            OPACITY_12: "#FF477E33",
            OPACITY_16: "#FF477E40",
            OPACITY_20: "#FF477E4D"
          };

          if (discord && discord.raw) {
            for (const key of Object.keys(discord.raw)) {
              if (key.startsWith("WHITE_")) {
                rawOverrides[key] = "#FF9EBB";
              } else if (key.startsWith("BLURPLE_") || key.startsWith("BRAND_")) {
                rawOverrides[key] = "#FF3366";
              } else if (key.startsWith("PLUM_")) {
                const num = parseInt(key.split("_")[1], 10);
                if (!isNaN(num)) {
                  if (num <= 6) rawOverrides[key] = "#FF9EBB";
                  else if (num <= 12) rawOverrides[key] = "#FFB3C6";
                  else if (num <= 16) rawOverrides[key] = "#FF85A1";
                  else if (num <= 20) rawOverrides[key] = "#731736";
                  else rawOverrides[key] = "#420D1F";
                }
              } else if (key.startsWith("NEUTRAL_")) {
                const num = parseInt(key.split("_")[1], 10);
                if (!isNaN(num)) {
                  if (num <= 15) rawOverrides[key] = "#FF9EBB";
                  else if (num <= 35) rawOverrides[key] = "#FFB3C6";
                  else if (num <= 50) rawOverrides[key] = "#FF85A1";
                  else if (num <= 70) rawOverrides[key] = "#731736";
                  else rawOverrides[key] = "#420D1F";
                }
              }
            }
          }

          return {
            semantic: {
              light: palette,
              dark: palette,
              darker: palette,
              midnight: palette
            },
            raw: rawOverrides
          };
        },
        background: {
          path: "https://files.catbox.moe/m7fniu.jpg",
          opacity: 0.88,
          blur: 0.12,
          dimming: 0.70
        }
      });
    }
  }
})
